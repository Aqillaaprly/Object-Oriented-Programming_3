
public interface Payable {
    public int getPaymentAmount();
}