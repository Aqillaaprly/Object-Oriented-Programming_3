package assigment;

public class Plant {
    public void doDestroy(Destroyable d) {
        d.destroyed();
    }
}