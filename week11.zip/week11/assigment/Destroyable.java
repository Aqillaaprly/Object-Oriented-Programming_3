package assigment;

    public interface Destroyable {
        void destroyed();
    } 