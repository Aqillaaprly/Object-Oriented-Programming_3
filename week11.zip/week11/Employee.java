
public class Employee {
    protected String mName;

    public String getEmployeeInfo() {
        return "Name = " + mName;
    }
}